package br.com.loja.entity;


import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class  ItemPedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer quantidade;
    /*
    @ManyToOne
    @JsonBackReference
    private Pedido pedido;
    /*
    @ManyToOne(fetch = FetchType.EAGER, cascade=CascadeType.ALL)
    @JoinColumn(name="id_pedido", nullable = false)
    @JsonBackReference
    Pedido pedido;



    @ManyToOne
    @JoinColumn(name = "id_produto")
    private Produto produto;



     */

}



