package br.com.loja.dtos.response;

import br.com.loja.entity.Cliente;

import java.util.List;
import java.util.stream.Collectors;

public class ClienteResponse {

    private Long id;
    private String email;
    private String nome;

    public ClienteResponse(Cliente cliente){
        this.id = cliente.getIdCliente();
        this.email = cliente.getEmail();
        this.nome = cliente.getNome();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public static List<ClienteResponse> converterParaListaCliente(List<Cliente> clientes){ ///Conversão de Tópico para TopicoDTO
        return clientes.stream().map(ClienteResponse::new).collect(Collectors.toList());
        //Map de Topico para TopicoDto //new >> chama o construtor que é o proprio Topico
    }
}
