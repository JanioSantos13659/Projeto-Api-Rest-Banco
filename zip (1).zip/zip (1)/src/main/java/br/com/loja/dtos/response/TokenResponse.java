package br.com.loja.dtos.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TokenResponse {

    private String token;
    private String tipo;

    public TokenResponse(String token, String tipo){
        this.token = token;
        this.tipo = tipo;
    }
}
