package br.com.loja.dtos.response;

import br.com.loja.entity.Pedido;
import br.com.loja.entity.Produto;
import lombok.Getter;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Getter
public class ProdutoResponse {

    private Integer Id;
    private String descrição;
    private BigDecimal valor;

    public ProdutoResponse(Produto produto){
        this.Id = produto.getIdProduto();
        this.descrição = produto.getDescricao();
        this.valor = produto.getValor();
    }

    public static List<ProdutoResponse> converterParaDto(List<Produto> produtos) {
            return produtos.stream().map(ProdutoResponse::new).collect(Collectors.toList());
        }

}
