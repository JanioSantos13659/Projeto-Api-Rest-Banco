/*package br.com.loja.dtos.request;


import br.com.loja.entity.Produto;
import br.com.loja.repository.ProdutoRespository;
import com.sun.istack.NotNull;

import javax.validation.constraints.NotEmpty;
import java.math.BigDecimal;

public class ProdutoForm { //Dados que vem da requisição

    @NotNull
    @NotEmpty
    private String descricao;
    @NotNull
    private BigDecimal valor;

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }
    public Produto converter(ProdutoRespository produtoRespository) {
        Produto produto = produtoRespository.findByDescricao(descricao);
        return new Produto(descricao,valor,produto);
    }

}*/




