package br.com.loja.repository;

import br.com.loja.entity.Pedido;
import br.com.loja.entity.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;

public interface PedidoRepository extends JpaRepository<Pedido, Integer> {

    Pedido findByidPedido(Integer idPedido);

}
