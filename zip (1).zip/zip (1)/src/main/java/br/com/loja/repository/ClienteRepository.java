package br.com.loja.repository;

import br.com.loja.entity.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;


public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    Optional<Cliente> findByemail(String username);

    //Produto findByidCliente(long id);

    //Produto findByNomeEmail(String email);
}
