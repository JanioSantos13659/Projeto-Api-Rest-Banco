package br.com.loja.dtos.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.jetbrains.annotations.NotNull;

import java.time.LocalDate;


@Getter
@Setter
@AllArgsConstructor
public class ItemRequest {

    private Integer quantidade;
    private Integer idProduto;


}

