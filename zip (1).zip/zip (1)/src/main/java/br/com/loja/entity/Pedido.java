package br.com.loja.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.*;

@Getter
@Setter
@Entity
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idPedido")
    private Integer idPedido;
    private LocalDate dataAtual = LocalDate.now();

    //@ManyToOne(fetch = FetchType.EAGER)
    //@JoinColumn(name = "idCliente")
    //private Cliente cliente;

    @ManyToOne
    private ItemPedido itemPedido;

    @ManyToOne
    private Produto produto;




    /*
    @OneToMany(fetch=FetchType.LAZY, mappedBy="pedido", cascade=CascadeType.ALL)
    @JsonManagedReference
   Set<ItemPedido> items = new HashSet<ItemPedido>();
     */

    /*
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "pedido", cascade = CascadeType.ALL)
    @JsonManagedReference
    private ItemPedido itens;


     */
    public Pedido() {

    }

    public Pedido(Integer idPedido, ItemPedido itemPedido, Produto produto,Pedido pedido) {
        this.idPedido = idPedido;
        this.itemPedido = itemPedido;
        this.produto = produto;
        pedido = pedido;
    }

}