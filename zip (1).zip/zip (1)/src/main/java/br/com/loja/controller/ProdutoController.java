package br.com.loja.controller;

//import br.com.loja.dto.request.ProdutoForm;
import br.com.loja.dtos.request.AtualizacaoTopicoForm;

import br.com.loja.dtos.response.ProdutoResponse;
import br.com.loja.entity.Produto;
import br.com.loja.repository.ProdutoRespository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import javax.transaction.Transactional;
import javax.validation.Valid;
import java.net.URI;
import java.util.List;



@RestController
@RequestMapping(value = "/api/produtos")
public class ProdutoController { /// Receber as requisiçãoes HTTP

     @Autowired
    ProdutoRespository produtoRespository; //importa o Repository


    @GetMapping() ///lista de produtos
    @Cacheable(value = "listaDeTopicos")
     public List<ProdutoResponse> listProdutos() {
        List<Produto> produtos = produtoRespository.findAll();
        return ProdutoResponse.converterParaDto(produtos);
    }


    /*@GetMapping
    @Transactional
    public Page<ProdutoDto> lista(@RequestParam(required = false) String descricao, @RequestParam int pagina, @RequestParam int qtd) {

        Pageable paginacao = PageRequest.of(pagina,qtd);

        if(descricao == null) {
            Page<Produto> topicos = produtoRespository.findAll(paginacao);
            return ProdutoDto.converterParaDto(topicos);
        } else {
            Page<Produto> topicos = produtoRespository.findByNomeDescricao(descricao, paginacao);
            return ProdutoDto.converterParaDto(topicos);
        }
    }

     */

   // @GetMapping("/{id}") /// Lista um Unico Produtos
   // public Produto listProdutosUnico(@PathVariable(value = "id") long id){
        //return produtoRespository.findByid(id);
    //}

    /*
    @PostMapping
    @Transactional
    @CacheEvict(value = "listaDeTopicos", allEntries = true)
    public ResponseEntity<ProdutoDto> cadastrarProduto(@RequestBody @Valid ProdutoForm form, UriComponentsBuilder uriBuilder) {
        Produto produto = form.converter(produtoRespository);
        produtoRespository.save(produto);

        URI uri = uriBuilder.path("/api/produtos/{id}").buildAndExpand(produto.getId()).toUri();
        return  ResponseEntity.created(uri).body(new ProdutoDto(produto));
    }

    /*@GetMapping("/{id}") ///Associado ao Long id
    @Transactional
    public ResponseEntity<DetalhesProdutoDto> detalharProdutoPorId(@PathVariable Long id) {
        Optional<Produto> produto = produtoRespository.findById(id);
        if (produto.isPresent()) {
            return ResponseEntity.ok(new DetalhesProdutoDto(produto.get()));
        }
        return ResponseEntity.notFound().build();
    }

     */

   @PostMapping() //Cadastro do Produto
    public Produto salvaProduto(@RequestBody @Valid Produto produto){
      return produtoRespository.save(produto);
    }
   /*@PostMapping
   public ResponseEntity<ProdutoDto> salvar(@RequestBody @Valid UsuarioDTO dto) {
       Produto produto = usuarioService.salvar(dto.transformaParaObjeto());
       return new ResponseEntity<>(UsuarioRespostaDTO.transformaEmDTO(usuario), HttpStatus.CREATED);
   }

    */
    /*@PutMapping("/{id}")

    @Transactional
    public ResponseEntity<ProdutoDto> atualizar(@PathVariable Long id, @RequestBody @Valid AtualizacaoTopicoForm form) {

        <Produto> optional = produtoRespository.findById(id);
        if (optional.isPresent()) {
            Produto produto = form.atualizar(id, produtoRespository);
            return ResponseEntity.ok(new ProdutoDto(produto));
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping() //deleta do Produto
    //public void deletaProduto(@RequestBody Produto produto){
      produtoRespository.delete(produto);
    //}


    @DeleteMapping("/{id}")
    @Transactional
    @CacheEvict(value = "listaDeTopicos", allEntries = true)
    public ResponseEntity<?> remover(@PathVariable Long id) {

        Optional<Produto> optional = produtoRespository.findById(id);
        if (optional.isPresent()) {
            produtoRespository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

   // @PutMapping() // Atualiza Produto
   // public Produto atualizaProduto(@RequestBody Produto produto){ // Recebe o Produto no corpo da requisação atravês dos Json
     //return produtoRespository.save(produto);
    //}



     */


}


