package br.com.loja.dtos.response;

import br.com.loja.dtos.request.ItemRequest;
import br.com.loja.entity.Cliente;
import br.com.loja.entity.ItemPedido;
import br.com.loja.entity.Pedido;
import lombok.Getter;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

//@AllArgsConstructor
@Getter
public class PedidoResponse { //Classe DTO >> são Dados da Api para o Cliente

    private Integer Id;
    private LocalDate dataAtual = LocalDate.now();
    private List<ItemPedido> items;


   public PedidoResponse(Pedido pedido) {
       this.Id = pedido.getIdPedido();
       this.dataAtual = pedido.getDataAtual();
    }

    public static List<PedidoResponse> convertePedido(List<Pedido> clientes) {
        return clientes.stream().map(PedidoResponse::new).collect(Collectors.toList());
    }



}
