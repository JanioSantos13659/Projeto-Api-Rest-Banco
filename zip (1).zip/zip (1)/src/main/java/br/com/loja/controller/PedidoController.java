package br.com.loja.controller;

import br.com.loja.dtos.request.PedidoRequest;
import br.com.loja.dtos.response.PedidoResponse;
import br.com.loja.entity.Cliente;
import br.com.loja.entity.Pedido;
import br.com.loja.repository.ItemProdutoRespository;
import br.com.loja.repository.PedidoRepository;
import br.com.loja.repository.ProdutoRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping(value = "/api/pedidos")
public class PedidoController {

    @Autowired
    PedidoRepository pedidoRepository;

    @Autowired
    ItemProdutoRespository itemProdutoRespository;

    @GetMapping
    public List<Pedido> listaPedidos() {
        List<Pedido> pedidos = pedidoRepository.findAll();
        return pedidos;
    }
    @GetMapping("/{id}")
    public Pedido listaUnicoPedido(@PathVariable (value = "id") Integer idPedido){
        return pedidoRepository.findByidPedido(idPedido);
    }

    @PostMapping
    public ResponseEntity<PedidoResponse> cadastra(@RequestBody PedidoRequest pedidoRequest, UriComponentsBuilder uriBuilder){
        Pedido pedido = pedidoRequest.converterPedido(itemProdutoRespository);
        pedidoRepository.save(pedido);

        URI uri = uriBuilder.path("/pedidos/{id}").buildAndExpand(pedido.getIdPedido()).toUri();

        return ResponseEntity.created(uri).body(new PedidoResponse(pedido));
    }


}
