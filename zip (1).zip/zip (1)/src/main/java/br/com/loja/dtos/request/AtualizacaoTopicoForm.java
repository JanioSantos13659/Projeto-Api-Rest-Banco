package br.com.loja.dtos.request;

import br.com.loja.entity.Produto;
import br.com.loja.repository.ProdutoRespository;
//import com.sun.istack.NotNull;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class AtualizacaoTopicoForm {


    @NotNull
    @NotEmpty
    private String descricao;
    @NotNull
    private BigDecimal valor;

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public Produto atualizar(Integer idProduto, ProdutoRespository produtoRespository) {
        Produto produto = produtoRespository.findByidProduto(idProduto);

        produto.setDescricao(this.descricao);
        produto.setValor(this.valor);

        return produto;
    }
}
