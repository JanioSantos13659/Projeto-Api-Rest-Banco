package br.com.loja.dtos.response;

import br.com.loja.entity.Produto;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class DetalhesProdutoDto {

    private Integer id;
    private String descricao;
    private BigDecimal valor;

    public DetalhesProdutoDto(Produto produto) {
        this.id = produto.getIdProduto();
        this.descricao = produto.getDescricao();
        this.valor = produto.getValor();
    }

}
