package br.com.loja.dtos.request;

import br.com.loja.entity.Cliente;
import br.com.loja.entity.ItemPedido;
import br.com.loja.entity.Pedido;
import br.com.loja.entity.Produto;
import br.com.loja.repository.ItemProdutoRespository;
import br.com.loja.repository.PedidoRepository;
import br.com.loja.repository.ProdutoRespository;
import lombok.Getter;
import lombok.Setter;
import org.jetbrains.annotations.NotNull;

import javax.persistence.JoinColumn;
import java.time.LocalDate;
import java.util.List;


@Getter
@Setter
public class PedidoRequest {


    private Integer idPedido;
    //private List<ItemRequest> items;
   private ItemPedido itemPedido;
   private Produto produto;

    public Pedido converterPedido(ItemProdutoRespository itemtoRespository) {
        Pedido pedido = itemtoRespository.findByid(idPedido);
        return new Pedido(idPedido,itemPedido,produto,pedido);
    }

}

