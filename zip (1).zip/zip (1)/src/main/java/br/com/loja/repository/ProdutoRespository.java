package br.com.loja.repository;


import br.com.loja.entity.Produto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.ArrayList;
import java.util.List;

public interface ProdutoRespository extends JpaRepository<Produto, Integer> { ///Entidade = Classe e Tipo Do ID
    ///Facilidade de Persistencia no banco de Dados

    Produto findByidProduto(Integer idProduto);



}
