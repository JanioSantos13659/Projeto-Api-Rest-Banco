package br.com.loja.controller;

import br.com.loja.dtos.response.ClienteResponse;
import br.com.loja.entity.Cliente;
import br.com.loja.entity.Pedido;
import br.com.loja.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/clientes")
public class ClienteController {

    @Autowired
    ClienteRepository clienteRepository;

    @GetMapping()
    public List<ClienteResponse> listClientes() {
        List<Cliente> clientes = clienteRepository.findAll();
        return ClienteResponse.converterParaListaCliente(clientes);
    }

    @PostMapping
    public Cliente cadastraCleinte (@RequestBody Cliente pedido){
        return clienteRepository.save(pedido);
    }

    @PutMapping
    public Cliente atualizaCliente(@RequestBody Cliente cliente){
        return clienteRepository.save(cliente);
    }
}

