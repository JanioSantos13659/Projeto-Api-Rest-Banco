package br.com.loja.repository;

import br.com.loja.entity.ItemPedido;
import br.com.loja.entity.Pedido;
import br.com.loja.entity.Produto;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ItemProdutoRespository extends JpaRepository<ItemPedido, Integer> {

    Pedido findByid(Integer idPedido);

    //Produto findByid(Integer idProduto);


}
